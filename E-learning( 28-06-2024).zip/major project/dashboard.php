<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dashboard</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-4"></div>
            <div class="col-lg-4"> 
                <h5 style="color:green;"> Welcome To The dashboard !!!</h5>
            </div>
            <div class="col-lg-4"></div>
        </div>
    </div>
</body>
</html>