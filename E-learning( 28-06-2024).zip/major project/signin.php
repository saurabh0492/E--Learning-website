<?php
// Simulated user database
$users = [];

header('Content-Type: application/json');

$username = $_POST['username'];
$password = $_POST['password'];

// Check if username and password are provided
if (empty($username) || empty($password)) {
    echo json_encode(['error' => 'Username and password are required']);
    exit;
}

// Check if username already exists
if (array_key_exists($username, $users)) {
    echo json_encode(['error' => 'Username already exists']);
    exit;
}

// Hash password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Store user data
$users[$username] = $hashedPassword;

echo json_encode(['message' => 'Signup successful']);
