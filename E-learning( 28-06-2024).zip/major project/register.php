<?php
include 'conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $name = $conn->real_escape_string($_POST['tName']);
    $contact_number = $conn->real_escape_string($_POST['number']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = ($_POST['password']); 

    $sql = "INSERT INTO  register (name, contact_number, email, password) VALUES ('$name', '$contact_number', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "<script type='text/javascript'>
        alert('You are registered successfully');
        window.location.href = 'index.php';
      </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
?>