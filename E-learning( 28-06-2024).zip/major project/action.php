<?php
session_start(); // Start session to store user authentication status

// Function to validate username and password
function validateCredentials($username, $password) {
    // Simulated user database
    $users = [
        ['username' => 'user1', 'password' => '$2y$10$QkL1ABY6rWU31VgDBRp.2.4rFL/fws.j4K9weRC1I5ZgSxKkhNLOK'], // Password: password1
        ['username' => 'user2', 'password' => '$2y$10$QkL1ABY6rWU31VgDBRp.2.4rFL/fws.j4K9weRC1I5ZgSxKkhNLOK']  // Password: password2
    ];

    // Find user in the database
    $user = array_filter($users, function ($user) use ($username) {
        return $user['username'] === $username;
    });

    if (empty($user)) {
        return ['error' => 'User not found'];
    }

    $user = reset($user);

    // Verify password
    if (!password_verify($password, $user['password'])) {
        return ['error' => 'Invalid password'];
    }

    // Authentication successful
    return ['message' => 'Login successful'];
}

// Function to register a new user
function registerUser($username, $password) {
    // Simulated user database
    $users = [];

    // Check if username and password are provided
    if (empty($username) || empty($password)) {
        return ['error' => 'Username and password are required'];
    }

    // Check if username already exists
    if (array_key_exists($username, $users)) {
        return ['error' => 'Username already exists'];
    }

    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Store user data
    $users[$username] = $hashedPassword;

    // Registration successful
    return ['message' => 'Signup successful'];
}

// Handle login action
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $result = validateCredentials($username, $password);

    if (isset($result['error'])) {
        $_SESSION['login_error'] = $result['error'];
    } else {
        $_SESSION['username'] = $username;
    }

    header('Location: index.php'); // Redirect back to the main page
    exit;
}

// Handle signup action
if (isset($_POST['signup'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $result = registerUser($username, $password);

    if (isset($result['error'])) {
        $_SESSION['signup_error'] = $result['error'];
    }

    header('Location: index.php'); // Redirect back to the main page
    exit;
}
