<?php
session_start();
if(!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LearnLab</title>
  <header>
    <img src="head.jpg">
    <centre><pre>                   LearnLab 
               Get that inspo!</pre></centre>
    
               <nav>
                <ul>
                    <li><a href="home.php"class="active">Home</a></li>
                    <li><a href="aboutus.html"class="active">About us</a></li>
                    <li><a href="contact.html"class="active"> Contact</a></li>
                    <li><a href="logout.php"class="active">Logout</a></li>
                </ul>
            </nav>
            
  </header>
</head>
  
   
  <link rel="stylesheet" href="home.css">
  <link rel="c++" href="c++.html"
</head>
<br>
<br>
  <div class="container">
    <div class="image">
      <img src="2.jpg">
    </div>
    <div class="text">
    <pre>
    Take student
    Experience to the 
    next level.  
      </pre>
    </div>
  </div>
  <br>
  <br>
  <br>
</body>
  <main>
  <inlne>
    <section class="module">
      <a href="java.html">
      <img src="java.jpg" alt="java"></a>
    </section>
    <section class="module">
      <a href="c++.html"> 
      <img src="c++.jpg" alt="c++">
     </a>
    </section>
  </inlne>
  <inline>
    <section class="module">
      <a href="python.html">
      <img src="pyy.jpg.png" alt="python">
    </a>
    </section>
    <section class="module">
      <a href="html.html">
      <img src="html.jpg" alt="">
    </a>
    </section>
   </inline>
   <inline>
    <section class="module">
      <a href="css.html">
      <img src="css.jpg" alt="css">
    </a>
    </section>
    <section class="module">
      <a href="javascript.html">
      <img src="jss.jpg" alt="javacript">
    </a>
    </section></inline>
  </main>
   <br>
   <br>
   
  <style>
    .footer {
      background-color: #2b8771;
      padding: 20px 0;
      font-family: 'Arial', sans-serif;
    }
    .footer-container {
      width: 80%;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    }
    .footer-section {
      flex: 1;
      padding: 0 15px;
      font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    }
    .footer-heading {
      color: #eef1f3;
      margin-bottom: 15px;
      font-weight: bold;
      font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    }
    .footer-links {
      font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
      list-style: none;
      padding: 0;
    }
    .footer-links li {
      margin-bottom: 10px;
    }
    .footer-links a {
      color: #0a0a0a;
      text-decoration: none;
      transition: color 0.3s;
    }
    .footer-links a:hover {
      color: #ebeff3;
    }
    .social-icons {
      display: flex;
    }
    .social-icons a {
      display: inline-block;
      width: 40px;
      height: 40px;
      background-color: #007bff;
      color: white;
      border-radius: 50%;
      margin-right: 10px;
      display: flex;
      justify-content: center;
      align-items: center;
      transition: background-color 0.3s;
    }
    .social-icons a:hover {
      background-color: #070707;
    }
  </style>
  </head>
  <body>
  
  <footer class="footer">
    <div class="footer-container">
      <!-- About Section -->
      <div class="footer-section">
        <h4 class="footer-heading">About Us</h4>
        <p>LearnLab is your go-to platform for online learning. Discover courses and tutorials crafted by leading experts.</p>
      </div>
      <!-- Contact Section -->
      <div class="footer-section">
        <h4 class="footer-heading">Contact</h4>
        <ul class="footer-links">
          <li><a href="mailto:contact@learnhub.com">saurabhtiwari0492@gmail.com</a></li>
          <li><a href="tel:+1234567890">+91 9628005636,9305400537</a></li>
        </ul>
      </div>
      <!-- Social Media Section -->
      <div class="footer-section">
        <h4 class="footer-heading">Follow Us</h4>
        <div class="social-icons">
           <p>instagram-saurabh_tiwari077</p>
                          
    </div>
  </footer>
  
  <script src="https://kit.fontawesome.com/yourkitcode.js" crossorigin="anonymous"></script>
  
  </body>
  </html>
  